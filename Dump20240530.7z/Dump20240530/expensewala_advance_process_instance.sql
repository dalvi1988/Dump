-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: ec2-52-66-213-22.ap-south-1.compute.amazonaws.com    Database: expensewala
-- ------------------------------------------------------
-- Server version	5.7.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `advance_process_instance`
--

DROP TABLE IF EXISTS `advance_process_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advance_process_instance` (
  `process_instance_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `advance_detail_id` bigint(20) NOT NULL,
  `voucher_status_id` int(11) NOT NULL,
  `pending_at` bigint(20) DEFAULT NULL,
  `processed_by` bigint(20) DEFAULT NULL,
  `comments` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`process_instance_id`),
  KEY `adv_id_adv_process_inst_idx` (`advance_detail_id`),
  KEY `voucher_status_adv_process_inst_idx` (`voucher_status_id`),
  KEY `pending_at_adv_process_inst_idx` (`pending_at`),
  KEY `approved_by_adv_process_inst_idx` (`processed_by`),
  CONSTRAINT `adv_id_adv_process_inst` FOREIGN KEY (`advance_detail_id`) REFERENCES `advance_details` (`advance_details_id`),
  CONSTRAINT `approved_by_adv_process_inst` FOREIGN KEY (`processed_by`) REFERENCES `employee_details` (`employee_id`),
  CONSTRAINT `pending_at_adv_process_inst` FOREIGN KEY (`pending_at`) REFERENCES `employee_details` (`employee_id`),
  CONSTRAINT `voucher_status_adv_process_inst` FOREIGN KEY (`voucher_status_id`) REFERENCES `voucher_status` (`voucher_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advance_process_instance`
--

LOCK TABLES `advance_process_instance` WRITE;
/*!40000 ALTER TABLE `advance_process_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `advance_process_instance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-30 21:30:30
